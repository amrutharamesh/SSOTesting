Examples of parsedatetime usage

basic.py            outlines all the "simple" usage
with_pyicu.py       using parsedatetime with PyICU
with_locale.py      using parsedatetime with built-in locale classes

